

<!--<script type="text/javascript" defer src="--><?//=get_template_directory_uri()?><!--/assets/js/owl.carousel.min.js"></script>-->


<?php wp_footer();?>
<footer>

    <div class="container">

        <div class="row">

            <div class="col-md-5">
                <div class="aboutfooter">
                    <img class="footer_img" src="http://localhost/ariashimi/wp-content/uploads/2023/06/logo-aryashimi.png">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
                    <h3>Subscribe to newsletter</h3>
                    <form action=#  method="get">
                        <label for="fname">Your Email Address</label>
                        <input type="submit" value="Go">
                    </form>
                    <p>UDesign WordPress © 2023. All Rights Reserved</p>
                </div>
            </div>
            <div class="col-md-2">
                
            </div>
            <div class="col-md-2"></div>
            <div class="col-md-3"></div>
        </div>
    </div>
</footer>

</body>
</html>
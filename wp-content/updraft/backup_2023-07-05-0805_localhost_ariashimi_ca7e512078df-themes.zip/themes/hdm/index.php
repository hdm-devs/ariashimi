<?php

get_header();

?>

<section class="first" style="float:right;width:100%;height:100vh;background:#14151a;"></section>

<?php

get_footer();

?>